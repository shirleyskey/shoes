<?php
/*
Plugin Name: WP Forms for AMP
Plugin URI: https://wordpress.org/plugins/accelerated-mobile-pages/
Description: WP forms plugin integration for AMP
Version: 1.1
Author: Ahmed Kaludi, Mohammed Kaludi
Author URI: https://ampforwp.com/
Donate link: https://www.paypal.me/Kaludi/25
License: GPL2+
Text Domain: AMP-for-WPFORMS
*/

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) exit;

define('AMPFORWP_WPFORMS_PLUGIN_DIR', plugin_dir_path( __FILE__ ));
define('AMPFORWP_WPFORMS_PLUGIN_DIR_URI', plugin_dir_url(__FILE__));
define('AMPFORWP_WPFORMS_VERSION','1.1');


// this is the URL our updater / license checker pings. This should be the URL of the site with EDD installed
define( 'AMP_WPFORMS_STORE_URL', 'https://accounts.ampforwp.com/' ); // you should use your own CONSTANT name, and be sure to replace it throughout this file

// the name of your product. This should match the download name in EDD exactly
define( 'AMP_WPFORMS_ITEM_NAME', 'WP Forms for AMP' );

if(! defined('AMP_WP_ITEM_FOLDER_NAME')){
    $folderName = basename(__DIR__);
    define( 'AMP_WP_ITEM_FOLDER_NAME', $folderName );
}

add_filter('wpforms_is_amp', 'enable_support_for_wpform');
add_action('plugins_loaded','ampforwp_wpforms_initiate_plugin');
function ampforwp_wpforms_initiate_plugin(){
	add_action('wp', 'amp_wpforms_start_form', 999);
	require_once AMPFORWP_WPFORMS_PLUGIN_DIR .'/class-amp-wpforms-blacklist.php';
}

add_filter('amp_content_sanitizers','ampforwp_wpforms_blacklist_sanitizer', 20);
function ampforwp_wpforms_blacklist_sanitizer($data){
    if ( isset($data['AMP_Blacklist_Sanitizer']) ) {
        unset($data['AMP_Blacklist_Sanitizer']);
        unset($data['AMPFORWP_Blacklist_Sanitizer']);
        unset($data['AMPFORWP_Wpforms_Blacklist']);
        $data[ 'AMPFORWP_Wpforms_Blacklist' ] = array();
    }

    return $data;
}

function amp_wpforms_start_form(){
	if ( (function_exists( 'ampforwp_is_amp_endpoint' ) && ampforwp_is_amp_endpoint()) ||  (function_exists( 'is_wp_amp' ) && is_wp_amp()) || (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) ) {	 

		//support For older than 0.9.9 older version
        add_filter('amp_post_template_data','amp_add_wpforms_required_scripts', 21);
		// replace original handler with our
		//remove_shortcode( 'wpforms' );
        add_shortcode( 'wpforms', 'ampforwp_wpforms_forms_shortcode' );

		

	}
}

if(!function_exists('ampforwp_wpforms_forms_shortcode')){
	function ampforwp_wpforms_forms_shortcode($atts, $content = null, $code = ''){
        $form_id    = (int) $atts['id'];
        $title    =  isset($atts['title'])? $atts['title']: '';
		$description 	=  isset($atts['description'])? $atts['description'] : '';
        // Grab the form data, if not found then we bail.
        $form = wpforms()->form->get( (int) $form_id  );

        if ( empty( $form ) ) {
            return;
        }
        add_action('amp_post_template_css', 'amp_wpforms_form_styling');
        ob_start();
        // Basic information.
        $form_data   = apply_filters( 'wpforms_frontend_form_data', wpforms_decode( $form->post_content ) );
        $form_id     = absint( $form->ID );
        $settings    = $form_data['settings'];
        $action      = esc_url_raw( remove_query_arg( 'wpforms' ) );
        $classes     = wpforms_setting( 'disable-css', '1' ) == '1' ? array( 'wpforms-container-full' ) : array();
        $errors      = empty( wpforms()->process->errors[ $form_id ] ) ? array() : wpforms()->process->errors[ $form_id ];
        $success     = false;
        $title       = filter_var( $title, FILTER_VALIDATE_BOOLEAN );
        $description = filter_var( $description, FILTER_VALIDATE_BOOLEAN );

        // If the form does not contain any fields do not proceed.
        if ( empty( $form_data['fields'] ) ) {
            echo '<!-- WPForms: no fields, form hidden -->';
            return;
        }

        // Before output hook.
        do_action( 'wpforms_frontend_output_before', $form_data, $form );

        // Check for return hash _or_ error free completed form.
        if ( ! empty( $_GET['wpforms_return'] ) ) {
            // Return hash check.
            $success = wpforms()->process->validate_return_hash( $_GET['wpforms_return'] );
            if ( $success ) {
                $args = array(
                    'content_only' => true,
                );
                $form_data = wpforms()->form->get( $success, $args );
            }
        } elseif ( ! empty( $_POST['wpforms']['id'] ) && absint( $_POST['wpforms']['id'] ) === $form_id && empty( $errors ) ) {
            // Completed form check.
            $success = true;
        }

        // Detect successful form submit, if found provide hook for
        // confirmation messages/actions and then stop.
        if ( $success && ! empty( $form_data ) ) {
            do_action( 'wpforms_frontend_output_success', $form_data );
            wpforms_debug_data( $_POST );
            return;
        }

        // Allow filter to return early if some condition is not met.
        if ( ! apply_filters( 'wpforms_frontend_load', true, $form_data, null ) ) {
            return;
        }

        // All checks have passed, so calculate multipage details for the form.
        $pages = wpforms_get_pagebreak_details( $form_data );
        /*if ( $pages ) {
            $this->pages = $pages;
        } else {
            $this->pages = false;
        }*/

        // Add the hash for confirmation scrolling if enabled.
        if ( ! empty( $settings['confirmation_type'] ) && 'message' === $settings['confirmation_type'] && ! empty( $settings['confirmation_message_scroll'] ) ) {
            $action .= '#wpforms-' . $form_id;
        }

        // Allow final action to be customized - 3rd param ($form) has been deprecated.
        $action = apply_filters( 'wpforms_frontend_form_action', $action, $form_data, null );

        // Allow form container classes to be filtered and user defined classes.
        $classes = apply_filters( 'wpforms_frontend_container_class', $classes, $form_data );
        if ( ! empty( $settings['form_class'] ) ) {
            $classes = array_merge( $classes, explode( ' ', $settings['form_class'] ) );
        }
        $classes = wpforms_sanitize_classes( $classes, true );

        // Begin to build the output
        printf(
            '<div class="wpforms-container %s" id="wpforms-%d">',
            $classes,
            $form_id
        );
        $submit_url =  admin_url('admin-ajax.php?action=amp_wpforms_submission');
        $actionXhrUrl = preg_replace('#^https?:#', '', $submit_url);
            printf(
                '<form method="post" enctype="multipart/form-data" id="wpforms-form-%d" action-xhr="%s" class="wpforms-validate wpforms-form" data-formid="%d"><div class="form-fields-wrapper">',
                $form_id,
                $actionXhrUrl,
                $form_id
            );
            echo wp_nonce_field('amp_wpforms_display_nonce','_wpnonce',true,false);
            do_action( 'wpforms_frontend_output', $form_data, null, $title, $description, $errors );
           echo  '</div>
            <div id="wpforms_'.$form_id.'" class="form-fields-wrapper">'.$content.'</div><div submit-success>
                <template type="amp-mustache" >
                  Success! {{message}}
                </template>
            </div>
            <div submit-error>
                <template type="amp-mustache" >
                    <div class="ampforwp-form-status amp_wpforms_error">
                    One or more fields have an error. Please enter required fields and try again.
                    <div class="ampforwp-form-status amp_gravity_error">
                     {{#errors}} 
                        <div>{{error_label}} : {{error_detail}}</div>
                     {{/errors}} 
                    </div> 
                    </div>
                </template>
            </div>
                ';
            echo '</form>';

        echo '</div>';

        // After output hook
        do_action( 'wpforms_frontend_output_after', $form_data, $form );

        // Add form to class property that tracks all forms in a page.
        //$this->forms[ $form_id ] = $form_data;

        // Optional debug information if WPFORMS_DEBUG is defined.
        wpforms_debug_data( $form_data );

        return ob_get_clean();
	}
}

function enable_support_for_wpform($status){
	$status = false;
	return $status;
};


function amp_add_wpforms_required_scripts($data){
    if ( is_singular() || is_home()) {
        // Adding Form Script
        if ( empty( $data['amp_component_scripts']['amp-form'] ) ) {
            $data['amp_component_scripts']['amp-form'] = 'https://cdn.ampproject.org/v0/amp-form-0.1.js';
        }
        // Adding bind Script
        if ( empty( $data['amp_component_scripts']['amp-bind'] ) ) {
            $data['amp_component_scripts']['amp-bind'] = 'https://cdn.ampproject.org/v0/amp-bind-0.1.js';
        }// Adding Mustache Script
        if ( empty( $data['amp_component_scripts']['amp-mustache'] ) ) {
            $data['amp_component_scripts']['amp-mustache'] = 'https://cdn.ampproject.org/v0/amp-mustache-latest.js';
        }
    }

    return $data;
}





function amp_wpforms_form_styling(){ ?>
    .form-fields-wrapper{width:100%;margin-bottom:25px;}
    .wpforms-field-label, .wpforms-field-sublabel{font-size: 11px;color: #555;letter-spacing: .5px;text-transform: uppercase;line-height: 1;}
    .wpforms-field{margin-bottom: 22px;}
    .form-fields-wrapper input{color: #111;width: 240px;padding: 10px 9px;border-radius: 2px;border: 1px solid #ccc;font-size: 14px;}
    .wpforms-one-half{display:inline-block;}
    .wpforms-form .wpforms-one-half input{display: block;float: none;}
    .wpforms-field-label{display:block;margin-bottom: 5px;}
    .form-fields-wrapper textarea{width:357px;height:192px;padding:10px 9px;}
    .wpforms-submit {background: #333;border: 0;font-size: 11px;padding: 15px 30px;text-transform: uppercase;margin-top: -5px;letter-spacing: 2px;font-weight: 700;color: #fff;box-shadow: 2px 3px 6px rgba(102,102,102,0.33);cursor: pointer;}
    .amp-form-submit-success #rendered-message-amp-form-1{
        background:green;
        colot:#fff;
        margin-top: -10px;
        padding: 10px 17px;
        margin-bottom: 20px;
        font-size: 15px;
        border: 1px solid rgba(0,0,0,0.14);
    }
    .wpforms-field.wpforms-field-hp {display: none;}
<?php
}//Css Function Closed 









add_action('wp_ajax_amp_wpforms_submission','amp_wpforms_submission');
add_action('wp_ajax_nopriv_amp_wpforms_submission','amp_wpforms_submission');

function amp_wpforms_submission(){
    if(!wp_verify_nonce($_POST['_wpnonce'],'amp_wpforms_display_nonce')){
        header('HTTP/1.1 500 FORBIDDEN');
    }else{
        if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['wpforms']) ){
            require_once AMPFORWP_WPFORMS_PLUGIN_DIR.'/amp-wpforms-submission.php';
        }
    }

    header("access-control-allow-credentials:true");
    header("access-control-allow-headers:Content-Type, Content-Length, Accept-Encoding, X-CSRF-Token");
    header("Access-Control-Allow-Origin:".$_SERVER['HTTP_ORIGIN']);
    $siteUrl = parse_url(
            get_site_url()
        );
    header("AMP-Access-Control-Allow-Source-Origin:".$siteUrl['scheme'] . '://' . $siteUrl['host']);
    header("access-control-expose-headers:AMP-Access-Control-Allow-Source-Origin");
    header("Content-Type:application/json");
     wp_die();
}


/**
*
* Update Codes
*
*
**/

// Notice to enter license key once activate the plugin

$path = plugin_basename( __FILE__ );
add_action("after_plugin_row_{$path}", function( $plugin_file, $plugin_data, $status ) {
    global $redux_builder_amp;
     if(! defined('AMP_WP_ITEM_FOLDER_NAME')){
    $folderName = basename(__DIR__);
        define( 'AMP_WP_ITEM_FOLDER_NAME', $folderName );
    }
    $pluginsDetail = @$redux_builder_amp['amp-license'][AMP_WP_ITEM_FOLDER_NAME];
    $pluginstatus = $pluginsDetail['status'];

    if(empty($redux_builder_amp['amp-license'][AMP_WP_ITEM_FOLDER_NAME]['license'])){
        echo "<tr class='active'><td>&nbsp;</td><td colspan='2'><a href='".esc_url(  self_admin_url( 'admin.php?page=amp_options&tabid=opt-go-premium' )  )."'>Please enter the license key</a> to get the <strong>latest features</strong> and <strong>stable updates</strong></td></tr>";
            }elseif($pluginstatus=="valid"){
                $update_cache = get_site_transient( 'update_plugins' );
        $update_cache = is_object( $update_cache ) ? $update_cache : new stdClass();
        if(isset($update_cache->response[ AMP_WP_ITEM_FOLDER_NAME ]) 
            && empty($update_cache->response[ AMP_WP_ITEM_FOLDER_NAME ]->download_link) 
          ){
           unset($update_cache->response[ AMP_WP_ITEM_FOLDER_NAME ]);
        }
        set_site_transient( 'update_plugins', $update_cache );
        
   }
}, 10, 3 );


/**
*    Plugin Update Method
**/
require_once dirname( __FILE__ ) . '/updater/EDD_SL_Plugin_Updater.php';
// Check for updates
function amp_wp_forms_plugin_updater() {

    // retrieve our license key from the DB
    //$license_key = trim( get_option( 'amp_ads_license_key' ) );
    $selectedOption = get_option('redux_builder_amp',true);
    $license_key = '';//trim( get_option( 'amp_ads_license_key' ) );
    $pluginItemName = '';
    $pluginItemStoreUrl = '';
    $pluginstatus = '';
    if( isset($selectedOption['amp-license']) && "" != $selectedOption['amp-license'] && isset($selectedOption['amp-license'][AMP_WP_ITEM_FOLDER_NAME])){

       $pluginsDetail = $selectedOption['amp-license'][AMP_WP_ITEM_FOLDER_NAME];
       $license_key = $pluginsDetail['license'];
       $pluginItemName = $pluginsDetail['item_name'];
       $pluginItemStoreUrl = $pluginsDetail['store_url'];
       $pluginstatus = $pluginsDetail['status'];
    }
    
    // setup the updater
    $edd_updater = new AMP_WP_FORMS_EDD_SL_Plugin_Updater( AMP_WPFORMS_STORE_URL, __FILE__, array(
            'version'   => AMPFORWP_WPFORMS_VERSION,                // current version number
            'license'   => $license_key,                        // license key (used get_option above to retrieve from DB)
            'license_status'=>$pluginstatus,
            'item_name' => AMP_WPFORMS_ITEM_NAME,          // name of this plugin
            'author'    => 'Mohammed Kaludi',                   // author of this plugin
            'beta'      => false,
        )
    );
}
add_action( 'admin_init', 'amp_wp_forms_plugin_updater', 0 );
