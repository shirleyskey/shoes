<?php

add_action('wpforms_process_complete', 'wpforms_process_submission_end', 10, 4);
function wpforms_process_submission_end($fields, $entry, $form_data, $entry_id) {
	// Get form
	$form_id = $_POST['wpforms']['id'];
			$form_data = wpforms()->form->get( $form_id, array(
				'content_only' => true,
			) );
		$message = '';
	if ( ! empty( $form_data['settings']['confirmation_type'] ) && 'message' == $form_data['settings']['confirmation_type'] ) {
		$message = $form_data['settings']['confirmation_message'];
	}
	echo json_encode(array("status"=>200, 'message'=> $message));
	
}
WPForms()->process->process(stripslashes_deep( $_POST['wpforms'] ))