=== WP Forms for AMP ===
Contributors: mohammed_kaludi, ahmedkaludi, ampforwp
Tags: AMP, contact forms, wp forms
Donate link: https://www.paypal.me/Kaludi/25
Requires at least: 3.0
Tested up to: 5.1.1
Stable tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Changelog ==

= 1.1 (26 April 2019) =

* Bugs Fixed:
    * AMP_DIR_ warning issue resolved.
    * Additional field issue resolved.
    * amp-mustache updated.
